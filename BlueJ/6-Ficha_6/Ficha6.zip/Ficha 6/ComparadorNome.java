
/**
 * Escreva a descrição da classe ComparadorNome aqui.
 * 
 * @author (seu nome) 
 * @version (número de versão ou data)
 */
public class ComparadorNome implements Comparator<Lugar>
{
    public int compare(Lugar l1,Lugar l2)
    {
        
    }
}
